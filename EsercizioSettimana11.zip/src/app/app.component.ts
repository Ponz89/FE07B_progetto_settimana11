import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import * as products from './products.service';

@Component({
  selector: 'app-root',
  template: `
    <!--The content below is only a placeholder and can be replaced.-->
    <app-navbar></app-navbar>
    <router-outlet></router-outlet>
  `,
  styles: [],
})
export class AppComponent {
  title = 'cart';
  loading: boolean = false;

  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    products.loadArticoli(this.http);
  }
}
