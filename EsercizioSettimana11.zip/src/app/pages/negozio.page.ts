import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../models/product';
import * as products from '../products.service';

@Component({
  template: `
    <p class="text-dark" *ngIf="isLoading">
      Caricamento lista Prodotti in corso..
    </p>
    <div class="mb-4" *ngFor="let prodotto of prodottoNegozio">
      <h5 class="card-header">{{ prodotto.id }}</h5>
      <div class="card-body">
        <h5 class="card-title">{{ prodotto.name }}</h5>
        <p class="card-text">
          {{ prodotto.description }} <br />
          <b>{{ prodotto.price }},00 €</b>
        </p>
        <button
          type="button"
          class="btn btn-dark text-warning"
          [routerLink]="['/dettagli', prodotto]"
        >
          Dettagli
        </button>
      </div>
    </div>
  `,
  styles: [
    `
      .mb-4 {
        background-color: rgba(53, 53, 245, 0.7);
        border-radius: 10px;
        box-shadow: 2px 2px 5px gray;
        max-width: 600px;
        margin-left: 10px;
        margin: 20px auto;
      }

      p:first-child {
        margin-top: 50vh;
        text-align: center;
        font-weight: bold;
      }

      .card-header {
        font-size: 30px;
      }

      .card-title {
        font-size: 30px;
        font-weight: bold;
      }

      .btn {
        border-radius: 50px;
      }
    `,
  ],
})
export class NegozioPage implements OnInit {
  prodottoNegozio: Product[] = [];

  isLoading = false;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.isLoading = true;
    setInterval(() => {
      if ((this.prodottoNegozio! = [])) {
        this.isLoading = false;
      }
      this.prodottoNegozio = products.prodotti;
    }, 2500);
  }
}
