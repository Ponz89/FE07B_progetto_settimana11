import { Component, OnInit } from '@angular/core';
import { Product } from '../models/product';
import * as products from '../products.service';
import { ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  template: `
    <div class="container">
      <ng-container
        *ngIf="
          prodottiCarrello && prodottiCarrello.length > 0;
          else elseTemplate
        "
      >
        <div class="mb-4" *ngFor="let prodotto of prodottiCarrello">
          <div class="card-body">
            <h5 class="card-title">{{ prodotto.name }}</h5>
            <p class="card-text">
              {{ prodotto.description }} <br />
              <b>{{ prodotto.price }},00 €</b>
            </p>
          </div>
        </div>
        <div class="container">
          <h2>Completa l'ordine</h2>
          <form #f="ngForm">
            <div ngModelGroup="userInfo">
              <div class="form-group">
                <label for="name">Nome</label>
                <input
                  class="form-control"
                  ngModel
                  name="nome"
                  type="text"
                  required
                  #name="ngModel"
                />
                <p>* Campo obbligatorio!</p>
                <br />
                <label for="indirizzo">Indirizzo</label>
                <input
                  class="form-control"
                  ngModel
                  name="indirizzo"
                  type="text"
                  required
                  #indirizzo="ngModel"
                />
                <p>* Campo obbligatorio!</p>
                <br />
                <button
                  (click)="submit(f)"
                  type="submit"
                  [disabled]="f.invalid"
                  class="btn btn-dark text-warning"
                >
                  Invia
                </button>
              </div>
            </div>
          </form>
        </div>
      </ng-container>
      <ng-template #elseTemplate>
        <h2 class="text-center">Il carrello è Vuoto.</h2>
      </ng-template>
    </div>
  `,
  styles: [
    `
      input.ng-invalid.ng-touched {
        border: 1px solid red;
      }
      .mb-4 {
        background-color: rgba(53, 53, 245, 0.7);
        border-radius: 10px;
        box-shadow: 2px 2px 5px gray;
        max-width: 600px;
        margin-left: 10px;
        margin: 20px auto;
      }

      .card-title {
        font-size: 30px;
        font-weight: bold;
      }

      .btn {
        border-radius: 50px;
      }

      h2.text-center {
        margin-top: 10vh;
        text-align: center;
        font-weight: bold;
      }
    `,
  ],
})
export class CarrelloPage implements OnInit {
  prodottiCarrello: Product[] = products.carrello;

  @ViewChild('f', { static: true }) form!: NgForm;

  user: any = {};

  submit(form: NgForm) {
    console.log('form inviato', form);
    this.user.nome = form.value.userInfo.nome;
    this.user.indirizzo = form.value.userInfo.indirizzo;

    let riepilogo = [];

    for (let i of this.prodottiCarrello) {
      riepilogo.push(i.name);
    }

    alert(
      'Grazie ' + this.user.nome + '! il tuo acquisto è andato a buon fine!'
    );

    products.carrello.length = 0;
    form.reset();
  }

  constructor() {}

  ngOnInit(): void {}
}
