import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';
import { Product } from '../models/product';
import * as products from '../products.service';

@Component({
  template: `
    <div class="mb-4" *ngIf="prodotto">
      <div class="card-body">
        <h5 class="card-title">{{ prodotto.name }}</h5>
        <p class="card-text">
          {{ prodotto.description }} <br />
          <b>{{ prodotto.price }},00 €</b>
        </p>
        <button
          type="button"
          class="btn btn-dark text-warning"
          (click)="aggiungi()"
        >
          Aggiungi al Carrello
        </button>
      </div>
    </div>
  `,

  styles: [
    `
      .mb-4 {
        background-color: rgba(53, 53, 245, 0.7);
        border-radius: 10px;
        box-shadow: 2px 2px 5px gray;
        max-width: 600px;
        margin-left: 10px;
        margin: 20px auto;
      }

      .card-title {
        font-size: 30px;
        font-weight: bold;
      }

      .btn {
        border-radius: 50px;
      }
    `,
  ],
})
export class CarrelloDettagliPage implements OnInit {
  prodotto!: Product;
  sub!: Subscription;

  constructor(private router: ActivatedRoute) {}

  ngOnInit(): void {
    this.sub = this.router.params.subscribe((params: Params) => {
      this.prodotto = <Product>params;
    });
  }

  aggiungi() {
    products.aggiungiAlCarrello(this.prodotto);
    alert('articolo aggiunto al carrello!')
  }

  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
}
