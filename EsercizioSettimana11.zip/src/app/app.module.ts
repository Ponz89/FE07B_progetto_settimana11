import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Route, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NegozioPage } from './pages/negozio.page';
import { CarrelloPage } from './pages/carrello.page';
import { CarrelloDettagliPage } from './pages/carrello-dettagli.page';
import { NavbarComponent } from './components/navbar.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

const routes: Route[] = [
  {
    path: '',
    component: NegozioPage,
  },
  {
    path: 'carrello',
    component: CarrelloPage,
  },
  {
    path: 'dettagli',
    component: CarrelloDettagliPage,
  },
];

@NgModule({
  declarations: [
    AppComponent,
    NegozioPage,
    CarrelloPage,
    CarrelloDettagliPage,
    NavbarComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
