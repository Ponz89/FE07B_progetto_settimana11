import { Product } from './models/product';
import { HttpClient } from '@angular/common/http';

export let prodotti: Product[] = [];
export let carrello: Product[] = [];

export function aggiungiAlCarrello(prodotto: Product) {
  carrello.push(prodotto);
}

export function rimuoviDalCarrello(prodotto: Product) {
  prodotti.push(prodotto);
  carrello.splice(carrello.indexOf(prodotto), 1);
}

export function loadArticoli(http: HttpClient): void {
  http.get('http://localhost:4201/products').subscribe((res) => {
    prodotti = <Product[]>res;
  });
}
